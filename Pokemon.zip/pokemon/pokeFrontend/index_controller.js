function gravar()
{
    var fdados=document.getElementById("fdados");
    var json=JSON.stringify(Object.fromEntries(new FormData(fdados)));
    var feedback=document.getElementById("feedback");
    //alert(json);
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: json,
        redirect: "follow"
      };
      
      fetch("http://localhost:8080/apis/add-pokemon", requestOptions)
        .then((response) => response.text())
        .then((result) =>{ feedback.innerHTML=result; fdados.reset()})
        .catch((error) => console.error(error));
    
}

function gravar2()
{
  var fdados=document.getElementById("fdados");
  var formdata = new FormData(fdados);
  
  var requestOptions = {
    method: 'POST',
    body: formdata,
    redirect: 'follow'
  };
  
  fetch("http://localhost:8080/apis/add-pokemon-img", requestOptions)
    .then(response => response.text())
    .then(result => {feedback.innerHTML=result; fdados.reset();})
    .catch(error => console.log('error', error));
}
//Itens B e C
document.addEventListener('DOMContentLoaded', function() {

  const endpoint = 'http://localhost:8080/apis/pokemon-tipos';

  fetch(endpoint)
    .then(response => response.json())
    .then(data => {

      const selectTipo = document.getElementById('tipo');

      data.forEach(tipo => {
        const option = document.createElement('option');
        option.value = tipo;  
        option.textContent = tipo ;  
        selectTipo.appendChild(option);
      });
    })
    .catch(error => {
      console.error('Erro ao carregar os tipos de Pokémon:', error);
    });
});

document.addEventListener('DOMContentLoaded', function() {
  const pokemonEndpoint = 'http://localhost:8080/apis/pokemons-filtro';  
  const searchInput = document.getElementById('search');
  const tableBody = document.querySelector('#pokemonTable tbody');

  function loadPokemons() {
    fetch(pokemonEndpoint)
      .then(response => response.json())
      .then(data => {
        displayPokemons(data); 
      })
      .catch(error => {
        console.error('Erro ao carregar os Pokémon:', error);
      });
  }

  function displayPokemons(pokemons) {
    tableBody.innerHTML = ''; 

    pokemons.forEach(pokemon => {
      const row = document.createElement('tr');
      
      const nameCell = document.createElement('td');
      nameCell.textContent = pokemon.nome;
      
      const typeCell = document.createElement('td');
      typeCell.textContent = pokemon.tipo;  

      row.appendChild(nameCell);
      row.appendChild(typeCell);
      
      row.addEventListener('click', () => {
        showPokemonDetails(pokemon, row);
      });

      tableBody.appendChild(row);
    });
  }
function showPokemonDetails(pokemon, element) {
  const imageExtension = '.jpg';  

  //const imagePath = `poke1.jpg`;
  //const imagePath = `poke2.jpg`;
  //const imagePath = `poke3.jpg`;
  //const imagePath = `poke4.jpg`;
  //const imagePath = `poke5.jpg`;
  const imagePath = `poke6.jpg`;

  const popoverContent = `
    <div class="text-center">
      <img src="${imagePath}" alt="${pokemon.nome}" style="width: 100px; height: 100px;">
      <p><strong>Nome:</strong> ${pokemon.nome}</p>
      <p><strong>Tipo:</strong> ${pokemon.tipo}</p>
      <p><strong>Nível:</strong> ${pokemon.nivel}</p>
    </div>
  `;

  const existingPopover = document.querySelector('.popover');
  if (existingPopover) {
    existingPopover.remove();
  }

  const popover = new bootstrap.Popover(element, {
    trigger: 'manual',
    html: true,
    content: popoverContent,
    placement: 'right',
  });

  popover.show();

  document.addEventListener('click', (e) => {
    if (!element.contains(e.target) && !document.querySelector('.popover').contains(e.target)) {
      popover.hide();
    }
  });
}  function filterPokemons() {
    const searchTerm = searchInput.value.toLowerCase();
    
    fetch(pokemonEndpoint)
      .then(response => response.json())
      .then(data => {
        const filteredPokemons = data.filter(pokemon => 
          pokemon.nome.toLowerCase().includes(searchTerm)
        );
        displayPokemons(filteredPokemons); 
      })
      .catch(error => {
        console.error('Erro ao filtrar os Pokémon:', error);
      });
  }

  loadPokemons();

  searchInput.addEventListener('input', filterPokemons);
});

