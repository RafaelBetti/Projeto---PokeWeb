package com.example.pokeweb.repositorios;

import com.example.pokeweb.entidades.Pokemon;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class PokeList {
    private List<Pokemon> pokemons;

    public PokeList() {
        pokemons=new ArrayList<>();
        // Adicionando Pokémon com suas características
        pokemons.add(new Pokemon("Pikachu", "Elétrico", 25));
        pokemons.add(new Pokemon("Charmander", "Fogo", 25));
        pokemons.add(new Pokemon("Bulbasaur", "Planta", 25));
        pokemons.add(new Pokemon("Squirtle", "Água", 25));
        pokemons.add(new Pokemon("Eevee", "Normal", 25));
        pokemons.add(new Pokemon("Jigglypuff", "Normal/Fada", 20));
        pokemons.add(new Pokemon("Gengar", "Fantasma/Veneno", 25));
        pokemons.add(new Pokemon("Snorlax", "Normal", 30));
        pokemons.add(new Pokemon("Mewtwo", "Psíquico", 100));
        pokemons.add(new Pokemon("Lucario", "Lutador/Aço", 30));
        pokemons.add(new Pokemon("Gardevoir", "Psíquico/Fada", 30));
        pokemons.add(new Pokemon("Charizard", "Fogo/Voando", 36));
        pokemons.add(new Pokemon("Dragonite", "Dragão/Voando", 55));
        pokemons.add(new Pokemon("Lapras", "Água/Gelo", 30));
        pokemons.add(new Pokemon("Alakazam", "Psíquico", 35));
        pokemons.add(new Pokemon("Machamp", "Lutador", 30));
        pokemons.add(new Pokemon("Onix", "Pedra/Steel", 25));
        pokemons.add(new Pokemon("Tyranitar", "Pedra/Sombra", 55));
        pokemons.add(new Pokemon("Gyarados", "Água/Voando", 35));
        pokemons.add(new Pokemon("Arcanine", "Fogo", 40));
        pokemons.add(new Pokemon("Sandslash", "Terra", 30));
        pokemons.add(new Pokemon("Togepi", "Fada", 15));
        pokemons.add(new Pokemon("Pidgeot", "Normal/Voando", 36));
        pokemons.add(new Pokemon("Nidoking", "Venenoso/Terra", 40));
        pokemons.add(new Pokemon("Nidoqueen", "Venenoso/Terra", 40));
        pokemons.add(new Pokemon("Venusaur", "Grama/Venenoso", 32));
        pokemons.add(new Pokemon("Blastoise", "Água", 32));
        pokemons.add(new Pokemon("Wigglytuff", "Normal/Fada", 28));
        pokemons.add(new Pokemon("Bellossom", "Grama", 30));
        pokemons.add(new Pokemon("Crobat", "Venenoso/Voando", 36));
        pokemons.add(new Pokemon("Donphan", "Terra", 30));
        pokemons.add(new Pokemon("Steelix", "Pedra/Aço", 35));
        pokemons.add(new Pokemon("Cyndaquil", "Fogo", 14));
        pokemons.add(new Pokemon("Quilava", "Fogo", 16));
        pokemons.add(new Pokemon("Typhlosion", "Fogo", 36));
        pokemons.add(new Pokemon("Totodile", "Água", 14));
        pokemons.add(new Pokemon("Croconaw", "Água", 16));
        pokemons.add(new Pokemon("Feraligatr", "Água", 30));
        pokemons.add(new Pokemon("Chikorita", "Grama", 14));
        pokemons.add(new Pokemon("Bayleef", "Grama", 16));
        pokemons.add(new Pokemon("Meganium", "Grama", 30));
        pokemons.add(new Pokemon("Teddiursa", "Normal", 16));
        pokemons.add(new Pokemon("Ursaring", "Normal", 30));
        pokemons.add(new Pokemon("Misdreavus", "Fantasma", 30));
        pokemons.add(new Pokemon("Pineco", "Inseto", 20));
        pokemons.add(new Pokemon("Forretress", "Inseto/Aço", 30));
        pokemons.add(new Pokemon("Shuckle", "Inseto/Rock", 20));
        pokemons.add(new Pokemon("Donphan", "Terra", 30));
        pokemons.add(new Pokemon("Houndoom", "Fogo/Sombra", 30));
        pokemons.add(new Pokemon("Zangoose", "Normal", 30));
        pokemons.add(new Pokemon("Seviper", "Venenoso", 30));
        pokemons.add(new Pokemon("Swayblue", "Dragão/Voando", 30));
        pokemons.add(new Pokemon("Altaria", "Dragão/Voando", 40));
        pokemons.add(new Pokemon("Roselia", "Grama/Venenoso", 32));
        pokemons.add(new Pokemon("Lucario", "Lutador/Aço", 30));
        pokemons.add(new Pokemon("Gallade", "Lutador/Psíquico", 30));
        pokemons.add(new Pokemon("Gardevoir", "Psíquico/Fada", 30));
        pokemons.add(new Pokemon("Gliscor", "Solo/Voador", 30));
        pokemons.add(new Pokemon("Grotle", "Grama", 30));
        pokemons.add(new Pokemon("Torterra", "Grama/Terra", 35));
        pokemons.add(new Pokemon("Monferno", "Fogo/Lutador", 30));
        pokemons.add(new Pokemon("Infernape", "Fogo/Lutador", 35));
        pokemons.add(new Pokemon("Prinplup", "Água", 30));
        pokemons.add(new Pokemon("Empoleon", "Água/Aço", 30));
        pokemons.add(new Pokemon("Luxio", "Elétrico", 30));
        pokemons.add(new Pokemon("Luxray", "Elétrico", 30));
        pokemons.add(new Pokemon("Roserade", "Grama/Venenoso", 36));
        pokemons.add(new Pokemon("Buizel", "Água", 14));
        pokemons.add(new Pokemon("Floatzel", "Água", 30));
        pokemons.add(new Pokemon("Cherubi", "Grama", 18));
        pokemons.add(new Pokemon("Cherrim", "Grama", 30));
        pokemons.add(new Pokemon("Shellos", "Água", 14));
        pokemons.add(new Pokemon("Gastrodon", "Água/Terra", 30));
        pokemons.add(new Pokemon("Ambipom", "Normal", 30));
        pokemons.add(new Pokemon("Drifloon", "Fantasma/Voador", 20));
        pokemons.add(new Pokemon("Drifblim", "Fantasma/Voador", 40));
        pokemons.add(new Pokemon("Buneary", "Normal", 20));
        pokemons.add(new Pokemon("Lopunny", "Normal", 30));
        pokemons.add(new Pokemon("Mismagius", "Fantasma", 30));
        pokemons.add(new Pokemon("Honchkrow", "Sombra/Voador", 40));
        pokemons.add(new Pokemon("Glameow", "Normal", 20));
        pokemons.add(new Pokemon("Purugly", "Normal", 30));
        pokemons.add(new Pokemon("Stunky", "Venenoso/Inseto", 20));
        pokemons.add(new Pokemon("Skuntank", "Venenoso/Noturno", 30));
        pokemons.add(new Pokemon("Bronzor", "Metal/Psíquico", 20));
        pokemons.add(new Pokemon("Bronzong", "Metal/Psíquico", 30));
        pokemons.add(new Pokemon("Bonsly", "Pedra", 20));
        pokemons.add(new Pokemon("Sudowoodo", "Pedra", 30));
        pokemons.add(new Pokemon("Andrew", "Normal", 30));
        pokemons.add(new Pokemon("Piplup", "Água", 14));
        pokemons.add(new Pokemon("Porygon-Z", "Normal", 30));
        pokemons.add(new Pokemon("Porygon", "Normal", 20));
        pokemons.add(new Pokemon("Porygon2", "Normal", 35));
    }
    public Pokemon getOne(String nome){
        Pokemon aux=null;
        for(Pokemon pokemon:pokemons)
            if(pokemon.getNome().equalsIgnoreCase(nome))
               aux=pokemon;
        return aux;
    }
    public List<Pokemon> getByType(String tipo)
    {
        List<Pokemon> pokemonList=new ArrayList<>();
        for(Pokemon pokemon:pokemons)
            if(pokemon.getTipo().equalsIgnoreCase(tipo))
                pokemonList.add(pokemon);
        return pokemonList;
    }
    public boolean add(Pokemon pokemon)
    {
        if(!pokemon.getNome().isEmpty())
        {
            pokemons.add(pokemon);
            return true;
        }
        return false;
    }

    public List<Pokemon> getAll() {
        return pokemons;
    }

    public List<Pokemon> getByNamePart(String name) {
        // Usando Stream API para filtrar a lista
        return pokemons.stream()
                .filter(pokemon -> pokemon.getNome().toLowerCase().contains(name.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<String> getAllTypes() {
        return pokemons.stream()
                .map(Pokemon::getTipo) // Mapeia cada Pokémon ao seu tipo
                .distinct() // Remove duplicatas
                .collect(Collectors.toList()); // Coleta os tipos únicos em uma lista
    }
}
