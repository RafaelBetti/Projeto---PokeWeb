package com.example.pokeweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokewebApplication {

    public static void main(String[] args) {
        SpringApplication.run(PokewebApplication.class, args);
    }

}
