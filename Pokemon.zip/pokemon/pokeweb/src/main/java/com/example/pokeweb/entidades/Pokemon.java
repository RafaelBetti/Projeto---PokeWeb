package com.example.pokeweb.entidades;

public class Pokemon {
    private String nome;
    private String tipo;
    private int nivel;

    public String getImagem() {
        return imagem;
    }

    private String imagem;

    public Pokemon(String nome, String tipo, int nivel) {
        this.nome = nome;
        this.tipo = tipo;
        this.nivel = nivel;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public void setImagem(String imagem) {
        this.imagem=imagem;
    }
}
