package com.example.pokeweb.restcontrollers;

import com.example.pokeweb.entidades.Pokemon;
import com.example.pokeweb.repositorios.PokeList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping(value="/apis")
public class PokeController {
    @Autowired
    private ResourceLoader resourceLoader;

    @Autowired
    private PokeList pokeList;

    @GetMapping(value="/")
    public ResponseEntity<Object> bemVindo()
    {
        return ResponseEntity.ok("Bem vindo à API de Pokemon");
    }
    //Query- 1 parâmetro

    @GetMapping(value="/get-pokemon")
    public ResponseEntity<Object> getPokemon(@RequestParam(value="nome") String nome)
    {
        Pokemon aux=pokeList.getOne(nome);
        if(aux==null)
            return ResponseEntity.badRequest().body("Pokemon não existe");
        else
            return ResponseEntity.ok(aux);
    }

    @GetMapping(value = "/get-by-type/{tipo}")
    public ResponseEntity<Object> getPokemonByType(@PathVariable(value="tipo") String tipo)
    {
        List<Pokemon> pokemonList=pokeList.getByType(tipo);
        if(pokemonList.isEmpty())
            return ResponseEntity.badRequest().body("Nenhum encontrado");
        else
            return ResponseEntity.ok(pokemonList);
    }
    @PostMapping(value="/add-pokemon")
    public ResponseEntity<Object> addPokemon(@RequestBody Pokemon pokemon)
    {
        if(pokeList.add(pokemon))
            return ResponseEntity.ok(pokemon);
        else
            return ResponseEntity.badRequest().body("Não é possível cadastrar o pokemon");
    }


    @PostMapping(value="/add-pokemon-img")
    public ResponseEntity<Object> addPokemonImage(String nome, String tipo, String nivel, MultipartFile imagem)
    {
        Pokemon pokemon=null;
        boolean erro=false;
        try{
            String filename=""+(new Date().getTime())+imagem.getOriginalFilename().substring(imagem.getOriginalFilename().lastIndexOf("."));
            Files.copy(imagem.getInputStream(), Paths.get(getStaticPath()).resolve(filename));
            pokemon=new Pokemon(nome,tipo, Integer.parseInt(nivel));
            pokemon.setImagem(filename);
            pokeList.add(pokemon);
        }
        catch(Exception e){
            System.out.println(e);
            erro=true;
        }

        if(!erro)
            return ResponseEntity.ok(pokemon);
        else
            return ResponseEntity.badRequest().body("Não é possível cadastrar o pokemon");
    }

    public String getStaticPath() throws IOException {
        String staticPath = null;
        staticPath = resourceLoader.getResource("classpath:static").getFile().getAbsolutePath();
        return staticPath;
    }


    //A) Crie um end-point para retornar todos os tipos de pokemons (lista json)
    @GetMapping("/pokemon-tipos")
    public ResponseEntity<List<String>> getAllPokemonTypes() {
        List<String> pokemonTypes = pokeList.getAllTypes();
        return ResponseEntity.ok(pokemonTypes);
    }


    //B) Crie um end-point para retornar uma relação de pokemons de acordo com um filtro de busca pela parte de seu nome.
    @GetMapping("/pokemons-filtro")
    public ResponseEntity<List<Pokemon>> getPokemonByNamePart(@RequestParam(value = "name", required = false) String name) {
        List<Pokemon> pokemons;
        if (name == null || name.isEmpty()) {
            pokemons = pokeList.getAll();
        } else {
            pokemons = pokeList.getByNamePart(name);
        }
        return ResponseEntity.ok(pokemons);
    }
}
