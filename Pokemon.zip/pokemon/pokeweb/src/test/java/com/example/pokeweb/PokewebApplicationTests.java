package com.example.pokeweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokewebApplicationTests {

    @Test
    void contextLoads() {
    }

}
